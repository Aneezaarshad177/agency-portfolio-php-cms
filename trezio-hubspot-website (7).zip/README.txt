TREZIO HUBSPOT WEBSITE - QUICK START

1. Upload every file and folder in this zip into your hosting's main website folder (usually "public_html").
   Keep the folders: admin, css, js, data, uploads. Files like index.html must sit directly inside public_html.
2. Open yourwebsite.com/admin/ in your browser.
3. Log in with the test details, then immediately open "Password" in the left menu and change them.
4. Edit anything, then click "Save changes". Your live website updates straight away.

Your hosting must support PHP (almost all shared hosting does). The folders "data" and "uploads" must be writable (permission 755 or 775).
Never delete the "data" folder: it holds all your content.
